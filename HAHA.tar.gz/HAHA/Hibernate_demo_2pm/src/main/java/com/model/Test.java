package com.model;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;



public class Test {
	
	public static void main(String[] args) {
		
		
		//add();
		//getAll();
		//update();
		//delete();
		hqlQuery();
	
		
	}
	
	static void add() {
		
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		Student s = new Student("Anita", "KC", "9876347567", "Toronto", "Female");
		session.save(s);
		session.getTransaction().commit();
		session.close();
		
		
	}
	
	static void getAll() {
		
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		
		
		
		Criteria crt = session.createCriteria(Student.class);
		List<Student> slist	= crt.list();// select sql
		System.out.println(slist);
		
	}
	
	static void update() {
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		Student s = (Student) session.get(Student.class, 3);
		s.setFname("Gaurav");
		session.update(s);
		
		session.getTransaction().commit();
		session.close();
		
		
	}
	
	static void delete() {
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		Student s = (Student) session.get(Student.class, 6);
		session.delete(s);
		session.getTransaction().commit();
		session.close();
	
	}
	
	static void hqlQuery() {
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();

		
		
		String HQL = "insert into Student1(address,fname,gender,lname,phone)"+"select address,fname,gender,lname,phone from Student";
		Query query = session.createQuery(HQL);
		session.beginTransaction();
		
		int executeUpdate = query.executeUpdate();
		if(executeUpdate>0) {
		System.out.println(executeUpdate+" records are inserted successfully");
			
		session.getTransaction().commit();	
		session.close();
			
		}
		
		
	}

}
