package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_table")
public class Student {
	
	@Id
	@GeneratedValue
	@Column 
	private int id;
	@Column
	private String fname;
	@Column
	private String lname;
	@Column
	private String phone;
	@Column
	private String address;
	@Column
	private String gender;
	
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	public Student(int id, String fname, String lname, String phone, String address, String gender) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.phone = phone;
		this.address = address;
		this.gender = gender;
	}






	public Student(String fname, String lname, String phone, String address, String gender) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.phone = phone;
		this.address = address;
		this.gender = gender;
	}






	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "\n Student [id=" + id + ", fname=" + fname + ", lname=" + lname + ", phone=" + phone + ", address="
				+ address + ", gender=" + gender + "]";
	}
	
	

}
