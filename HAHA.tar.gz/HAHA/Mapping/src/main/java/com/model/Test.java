package com.model;

import java.util.Arrays;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Test {
	
	
	public static void main(String[] args) {
		
		//oneToone();
		//oneTomany();
		manyTomany();
		
	}
	
	static void oneToone() {
		
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		
		Address adr = new Address();
		adr.setCountry("Nepal");
		adr.setState("Koshi");
		session.save(adr);
		
		
		Employee emp = new Employee();
		emp.setName("Kamal Thakuri");
		emp.setAge(23);
		emp.setAddress(adr);
		
		session.save(emp);
		session.getTransaction().commit();
		session.close();
		
		
	}
	static void oneTomany() {
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		
		Address adr = new Address();
		adr.setCountry("Nepal");
		adr.setState("Koshi");
		session.save(adr);
		
		
		Employee emp = new Employee();
		emp.setName("Kamal Thakuri");
		emp.setAge(23);
		emp.setAddress(adr);
		
		Phone ph1 = new Phone();
		ph1.setEmp(emp);
		ph1.setCompany("NTC");
		ph1.setNumber("9842422424");
		
		session.save(ph1);
		
		Phone ph2 = new Phone();
		ph2.setEmp(emp);
		ph2.setCompany("NCELL");
		ph2.setNumber("982323535");
		
		session.save(ph2);
		
		emp.setPhones(Arrays.asList(ph1,ph2));
		
		session.save(emp);
		session.getTransaction().commit();
		session.close();
		
		
	}
	
	static void manyTomany() {
		
		
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		
		
		Address adr = new Address();
		adr.setCountry("Nepal");
		adr.setState("Koshi");
		session.save(adr);
		
		
		Employee emp = new Employee();
		emp.setName("Kamal Thakuri");
		emp.setAge(23);
		emp.setAddress(adr);
		
		Phone ph1 = new Phone();
		ph1.setEmp(emp);
		ph1.setCompany("NTC");
		ph1.setNumber("9842422424");
		
		session.save(ph1);
		
		Phone ph2 = new Phone();
		ph2.setEmp(emp);
		ph2.setCompany("NCELL");
		ph2.setNumber("982323535");
		
		session.save(ph2);
		
	
		
		
		Department d1 = new Department();
		d1.setName("Finance");
		session.save(d1);
		
		Department d2 = new Department();
		d2.setName("IT");
		session.save(d2);
		
		emp.setPhones(Arrays.asList(ph1,ph2));
		emp.setDepartments(Arrays.asList(d1,d2));
		
		
		session.save(emp);
		session.getTransaction().commit();
		session.close();
		
		
		
		
	}
	
	

}
