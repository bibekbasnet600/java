package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Department;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.service.DepartmentService;
@Service
public class DepartmentServiceImpl implements DepartmentService {
	
	@Autowired
	private DepartmentRepository departmentRepo;

	@Override
	public void addDepartment(Department department) {
		
		departmentRepo.save(department);
	}

	@Override
	public void deleteDepartment(int id) {
		departmentRepo.deleteById(id);
		
	}

	@Override
	public List<Department> getAllDepartment() {
		
		return departmentRepo.findAll();
	}

	@Override
	public void updateDept(Department department) {
		
		departmentRepo.save(department);
		
	}

	@Override
	public Department getById(int id) {
		
		return departmentRepo.findById(id).get();
	}

}
