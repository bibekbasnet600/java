package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Employee;

public interface EmployeeService {
	
	void addEmployee(Employee employee);
	void deleteEmployee(Long id);
	List<Employee> getAllEmployees();
	void updateEmployee(Employee employee);
	Employee getById(Long id);
}
