package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository employeeRepo;

	@Override
	public void addEmployee(Employee employee) {
		
		employeeRepo.save(employee);
		
	}

	@Override
	public void deleteEmployee(Long id) {
		
		employeeRepo.deleteById(id);
		
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return employeeRepo.findAll();
	}

	@Override
	public void updateEmployee(Employee employee) {
		
		employeeRepo.save(employee);		
	}

	@Override
	public Employee getById(Long id) {
		
		return employeeRepo.findById(id).get();
	}

}
