package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Employee;
import com.example.demo.service.DepartmentService;
import com.example.demo.service.EmployeeService;
import com.example.demo.utils.EmployeeExcelView;

import jakarta.servlet.http.HttpSession;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService service;
	
	@Autowired
	private DepartmentService dptService;

	@GetMapping("/employee")
	public String getEmployee(Model model, HttpSession session) {
		
		if(session.getAttribute("validuser")==null) {
			
			return "LoginForm";
		}
		model.addAttribute("deptList", dptService.getAllDepartment());

		return "EmployeeForm";
	}

	@PostMapping("/employee")
	public String postEmployee(@ModelAttribute Employee employee) {

		service.addEmployee(employee);

		return "redirect:/employee";
	}
	
	@GetMapping("/empList")
	public String getAll(Model model, HttpSession session) {
		if(session.getAttribute("validuser")==null) {
			
			return "LoginForm";
		}
		
		model.addAttribute("eList", service.getAllEmployees());
		
		return "EmployeeList";
		
		
	}
	
	@GetMapping("/empdelete")
	public String deleteEmployee(@RequestParam Long id) {
		
		service.deleteEmployee(id);
		
		
		
		return "redirect:/empList";
	}
	@GetMapping("/empedit/{id}")
	public String getEmpById(@PathVariable Long id, Model model) {
		
		model.addAttribute("empObject", service.getById(id));
		model.addAttribute("deptList", dptService.getAllDepartment());
		
		
		return "EditEmployeeForm";
	}
	
	@PostMapping("/updateEmp")
	public String updateEmp(@ModelAttribute Employee emp) {
		
		service.updateEmployee(emp);
		
		return "redirect:/empList";
	}
	
	@GetMapping("/excel")
	public ModelAndView exportToExcel() {
		ModelAndView m =  new ModelAndView();
		m.setView(new EmployeeExcelView());

		//read data from DB
		List<Employee> list = service.getAllEmployees();
		//send to Excel Impl class
		m.addObject("list", list);

		return m;
	}
	
	
	

}
