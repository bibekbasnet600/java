package com.example.demo.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;



@RestController
public class EmployeeRestApi {
	
	@Autowired
	private EmployeeService service;
	
	@GetMapping("/api/emp/list")
	public List<Employee> getAllEmps() {
		
		
		return service.getAllEmployees();
	}
	
	@PostMapping("/api/emp/add")
	public String addEmps(@RequestBody Employee emp) {
		
		
		
		service.addEmployee(emp);
		return "success";
	}

}
