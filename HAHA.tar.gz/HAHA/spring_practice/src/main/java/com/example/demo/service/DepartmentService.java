package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Department;

public interface DepartmentService {
	
	void addDepartment(Department department);
	void deleteDepartment(int id);
	List<Department> getAllDepartment();
	void updateDept(Department department);
	Department getById(int id);
	

}
