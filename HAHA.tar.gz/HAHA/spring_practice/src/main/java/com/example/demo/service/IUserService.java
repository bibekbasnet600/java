package com.example.demo.service;

import com.example.demo.model.User;

public interface IUserService {
	
	User loginUser(String un, String psw);
	void signupUser(User user);
	

}
