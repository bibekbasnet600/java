package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.utils.MailUtil;

import jakarta.servlet.http.HttpSession;

@Controller
public class EmailController {
	
	@Autowired
	private MailUtil mailutil;
	
	@GetMapping("/email")
	public String getEmail(HttpSession session) {
		if(session.getAttribute("validuser")==null) {
			
			return "LoginForm";
		}
		
		return "EmailForm";
	}
	
	@PostMapping("/email")
	public String postEmail(@RequestParam String to, @RequestParam String subject, @RequestParam String message) {
		
		mailutil.sendEmail(to,subject,message);
		
		return "EmailForm";
	}

}
