package oop;

import java.util.Scanner;

public class Student {

	String name;
	int roll_no;
	

	void printStudent() {
		
		System.out.println("Student name : "+name);
		System.out.println("Roll no : "+roll_no);
		
	}
	
	
	public static void main(String[] args) {
		
		try (Scanner sc = new Scanner(System.in)) {
			Student s = new Student();

			System.out.println("Enter student name : ");
			s.name = sc.next();
			
			System.out.println("Enter a roll no : ");
			s.roll_no = sc.nextInt();
			
			
			s.printStudent();
		}
		
	}
	
	
}
