package oop;

import java.util.Scanner;

public class ZoomLent {
	
	String name = "Sam";
	String name1 = "john";
	int roll_no;
	String phone_number;
	String address;
	int roll_no1;
	String phone_number1;
	String address1;
	
	void printSam() {
		System.out.println("Student name : "+name);
		System.out.println("Roll no : "+roll_no);
		System.out.println("Phone number : "+phone_number);
		System.out.println("Address : "+address);
		
		
	}
	void printJohn() {
		
		System.out.println("Student name : "+name1);
		System.out.println("Roll no : "+roll_no1);
		System.out.println("Phone number : "+phone_number1);
		System.out.println("Address : "+address1);
		
	}
	
	
	
	public static void main(String[] args) {
		
		try (Scanner sc = new Scanner(System.in)) {
			ZoomLent z = new ZoomLent();
			System.out.println("Enter student Sam detail : ");
			System.out.println("Enter a roll no : ");
			z.roll_no = sc.nextInt();
			System.out.println("Enter a phone number : ");
			z.phone_number= sc.next();
			System.out.println("Enter an address : ");
			z.address = sc.next();
			System.out.println("\t");
			System.out.println("--------------------------------");
			System.out.println("\t");
			System.out.println("Enter Student John details : ");
			System.out.println("Enter a roll no : ");
			z.roll_no1 = sc.nextInt();
			System.out.println("Enter a phone number : ");
			z.phone_number1= sc.next();
			System.out.println("Enter an address : ");
			z.address1 = sc.next();
			
			z.printSam();
			System.out.println("\t");
			z.printJohn();
		}
		
		
	}

}
