package filehandling;

import java.io.FileWriter;
import java.io.IOException;

public class WriteFileUsingFileWriter {
	
	/*
	 * 1. FileWriter : write file
	 * 
	 * 2. FileReader : read file
	 * 
	 * 
	 */
	
	public static void main(String[] args) throws IOException {
		
		FileWriter file = new FileWriter("student.txt");
		
		file.write("ID = 21 \n");
		file.write("Name = Bibek Basnet \n");
		file.write("Age = 22 \n");
		file.write("College = Nepal College \n");
		file.write("Phone = 9873652532 \n");
		
		file.close();
		
		System.out.println("Success");
		
		
	}

}
