package filehandling;


import java.io.FileOutputStream;

import java.io.IOException;

public class CreateFileUsingInputStream {
	
	/*
	 * 1. File Input Stream : read file
	 * 
	 * 2. File Output 
	 * Stream : write file
	 * 
	 * 
	 */
	
	public static void main(String[] args) throws IOException {
		
		FileOutputStream file = new FileOutputStream("test1.txt");
		
		
		
		
		file.write("Hello Guys".getBytes());
		file.close();
		
		System.out.println("File Created.");
		
		
	}

}
