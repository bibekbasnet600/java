package filehandling;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class ReadFileUsingFileReader {
	
	
	public static void main(String[] args) throws IOException {
		
		FileReader file = new FileReader("college.csv");
		BufferedReader br = new BufferedReader(file);
		
		String line;
		
		
		while((line = br.readLine())!=null) {
			
			//System.out.println(line);
			
			String [] data = line.split(",");
			//System.out.println(data[0]);
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost/Student", "root", "Bibek72981!@");
				String sql = "insert into college(id,name,college,gender,age,address,phone)values('"+data[0]+"','"+data[1]+"','"+data[2]+"','"+data[3]+"','"+data[4]+"','"+data[5]+"','"+data[6]+"')";
				Statement stm = con.createStatement();
				stm.execute(sql);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
//			create student table
//			write insert sql and set values to sql
//			execute sql
			
			
		}
		
	}

}
