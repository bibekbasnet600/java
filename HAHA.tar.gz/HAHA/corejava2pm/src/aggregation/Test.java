package aggregation;

public class Test {
	
	public static void main(String[] args) {
		
		Car c = new Car();
		c.setColor("Silver-Grey");
		c.setModel("Porsche 911");
		c.setPrice(30000000);
		c.setCc(2200);
		
		
		Employee e = new Employee();
		e.setId(11);
		e.setName("Raju");
		e.setSalary(100000);
		e.setCar(c);
		
		System.out.println("=========== Employee Details ==============");
		System.out.println("Id = "+e.getId());
		System.out.println("Name = "+e.getName());
		System.out.println("Salary = "+e.getSalary());
		
		System.out.println("=========== Car Details ====================");
		System.out.println("Car Model = "+e.getCar().getModel());
		System.out.println("Car Color = "+e.getCar().getColor());
		System.out.println("Car Price = "+e.getCar().getPrice());
		System.out.println("Car CC = "+e.getCar().getCc());
	
		
	}

}
