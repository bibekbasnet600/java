package inheritance;

public class InheritanceDocs {
	
	/*
	 *  ============================= Inheritance =====================
	 *  
	 *  # use for code re-usability.
	 *  
	 *  # process of accessing properties and methods of parent/super/base class to its 
	 *  	child/sub/derived class is known as inheritance.
	 *  
	 *  # also known as IS-A relationship.
	 *  
	 *  # it's a generalization to specialization process.	
	 * 
	 * 	# we can't inherit private properties, methods and constructors.
	 * 
	 * 	# we can inherit static properties and methods.
	 * 
	 * 	# we can inherit only one class at a time.
	 * 
	 * 		Syntax : 
	 * 			
	 * 			class child_class_name extends parent_class_name{
	 * 				
	 * 				// properties : parent + child
	 * 
	 * 				// methods : parent + child
	 * 
	 * 			
	 * 			}
	 * 
	 * 
	 */

}
