package inheritance;

public class Programmer extends Employee{
	
	String progLang;
	String project;
	int bonus;
	
	void print() {
		
		super.print();
		System.out.println("Programming Language = "+progLang);
		System.out.println("Project = "+project);
		System.out.println("Bonus = "+bonus);
		
		
	}
	
	public static void main(String[] args) {
		
		Programmer p = new Programmer();
		
		p.id = 234;
		p.name = "Raghav";
		p.phone = "982352525";
		p.company = "Oracle";
		p.progLang = "Java";
		p.salary = 500000;
		p.bonus = 25000;
		p.project = "Open AI";
		
		p.print();
		
		
	}

}
