package inheritance;

public class Employee {
	
	int id; 
	String name;
	int salary;
	String phone;
	String company;
	
	void print() {
		
		System.out.println("Id = "+id);
		System.out.println("Name= "+name);
		System.out.println("Salary = "+salary);
		System.out.println("Phone = "+phone);
		System.out.println("Company = "+company);
	}

}
