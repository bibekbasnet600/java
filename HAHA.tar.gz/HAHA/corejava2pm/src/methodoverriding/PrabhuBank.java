package methodoverriding;

public class PrabhuBank extends CentralBank{

	
	@Override
	void getBankName() {
		
		System.out.println("Bank Name = Prabhu Bank");
	}
	
	@Override
	void getInterestRate() {
		
		System.out.println("Interest Rate = 10%");
	}
}
