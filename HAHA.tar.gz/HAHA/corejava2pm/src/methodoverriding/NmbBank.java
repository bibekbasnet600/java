package methodoverriding;

public class NmbBank extends CentralBank {
	
	@Override
	void getBankName() {
			System.out.println("Bank Name = NMB Bank");
	
	}
	
	@Override
	void getInterestRate() {
		
		System.out.println("Interest Rate = 15%");
	}
	
	

}
