package methodoverriding;

public class NCCBank extends CentralBank{
	
	@Override
	void getBankName() {
	
		System.out.println("Bank Name = NCC Bank");
	}
	
	@Override
	void getInterestRate() {
		
		System.out.println("Interest Rate = 8%");
	}

}
