package methodoverriding;

public class Test {
	
	public static void main(String[] args) {
		
		//static or early binding of object
//		NmbBank nmb = new NmbBank();
//		nmb.getBankName();
//		nmb.getInterestRate();
		
		//up-casting
		
		CentralBank b = new PrabhuBank();
		CentralBank b1 = new NCCBank();
		CentralBank b2 = new NmbBank();
		CentralBank b3 = new CentralBank();
		
		printBank(b);
		System.out.println("=====================");
		printBank(b1);
		System.out.println("=====================");
		printBank(b2);
		System.out.println("=====================");
		printBank(b3);
		
		
	}
	//dynamic or late binding of object
	//run-time polymorphism
	static void printBank(CentralBank b) {
		
		b.getBankName();
		b.getInterestRate();
		
	}

}
