package methodoverriding;

public class CentralBank {
	
	
	void getBankName() {
		System.out.println("Bank Name = Central Bank");
		
	}
	
	void getInterestRate() {
		
		System.out.println("Interest Rate = 0%");
		
	}
	
	void moneyExchangeRate() {
		
		System.out.println("$1 = Rs.132");
		System.out.println("1 Euro = Rs.145");
		System.out.println("100 IC = Rs.160");
	}

}
