package array;



public class ArrayAddEvenNums {
	
	
	
	public static void main(String[] args) {
		
		int values[] = {29,83,75,9,82,57,92,85,72,9,85,48,31,32,63,47,54};
		
		getEvenNums(values);
	
	}
	
	static void getEvenNums(int values[]) {
		int s=0;
		
		for(int x : values) {
			if(x%2==0) {
				
				
				System.out.println(x);
				s=s+x;
				
			}
			
			
		}
		
		
		System.out.println(s);

		
		
		
	}

}
