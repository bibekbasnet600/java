package array;

public class ArrayWithMethod {
	
	/*
	 * ================ Array with method ===================
	 * 
	 * a> array as arguments
	 * 
	 * 		void sum(int a[]){
	 * 
	 * 
	 * 	}
	 * 
	 * b> array as return type
	 * 
	 * 		String[] getValue(){
	 * 		//create
	 * 		//put values
	 * 
	 * 		return array of string;
	 * 	}
	 * 
	 * 
	 * 
	 */
	
	
	public static void main(String[] args) {
		
		//int values[] = {98,21,74,9,8,17,9,1,85,7,19};
		//int[] data = getIntArray();
		
		//sum(data);
		
		printArray(getIntArray());
	
		
	}
	
	//============== array as argument ===================
	
	static void sum(int array[]) {
		int s = 0;
		for(int x : array) {
			s= s+x;
			
		}
		System.out.println("Sum of array = "+s);
		
	}
	
	//================== array as return type ==================
	 
	static int[] getIntArray() {
		
		int  array[] = {9,87,25,987,325,98,27,52};
		return array;
		
	}
	
	static void printArray(int b[]) {
		
		for(int x : b) {
			
			System.out.println(x);
			
		}
		
	}
	
	
	

}
