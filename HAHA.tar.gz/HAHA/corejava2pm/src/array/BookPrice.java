package array;

import java.util.Scanner;

public class BookPrice {
	
	
	public static void main(String[] args) {
		
		float sum = 0;
		// 1+0= 1 1+4=5 10
		float price[] = new float[10];
		
		try (Scanner sc = new Scanner(System.in)) {
			for(int i = 0; i<price.length; i++) {
				
				System.out.println("Enter a price of book : ");
				
				price[i] = sc.nextFloat();
			}
		}
		
		for(float x: price) {
			
			System.out.println(x);
			
			sum = sum +x;
			
			
			
			}
		System.out.println("Total price of books : "+sum);
		
			
			
		}
		
		
		
	}


