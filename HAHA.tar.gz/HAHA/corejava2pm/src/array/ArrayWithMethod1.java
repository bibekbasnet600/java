package array;

import java.util.Arrays;

public class ArrayWithMethod1 {
	
	public static void main(String[] args) {
		
	int[] addnums = getOddNumber();
	System.out.println(Arrays.toString(addnums));
	}
	
	static int[] getOddNumber() {
		int oddnums[] = new int[50];
		int j =0;
		for(int i = 1; i<=100; i++) {
			if((i%2)!=0) {
				
				oddnums[j] = i;		
				j++;
			}
			
		}
		return oddnums;
		
		
	}
	
	

}
