package array;

public class ArrayDocs {
	
	/*
	 *  ============== Array ===================
	 *  
	 *  # collection of homogeneous data.
	 *  
	 *  # collection/group of multiple values of same data type.
	 *  
	 *  # have fixed length/size.
	 *  
	 *  # contains duplicate data.
	 *  
	 *  # random access.
	 * 
	 * 	# data store on the basis of indices.(index starts from 0).
	 * 
	 * 	# contiguous memory allocation.
	 * 
	 * 	# array is itself object in java.
	 * 
	 * 
	 * 
	 * 	# Syntax:
	 * 
	 * 		data_type array_name[] = new data_type[size];
	 */
	
	public static void main(String[] args) {
		
		
		
	}

}
