package array;

import java.util.Scanner;

public class SubjectMarksTest {

	public static void main(String[] args) {
		
		String subjects[] = new String[7];
		int marks[] = new int[7];
		//input
		for(int i=0; i<marks.length; i++) {
			
			try (Scanner sc = new Scanner(System.in)) {
				System.out.println("Enter a subject : ");
				subjects[i] = sc.next();
				System.out.println("Enter a marks for a subject: ");
				marks[i] = sc.nextInt();
			}
			
		}
		//output
		System.out.println("");
		System.out.println("Subjects : "+"                 "+"Marks : ");
		System.out.println("----------------------------------");
		
		for(int i = 0; i<marks.length; i++) {
			System.out.println(subjects[i]+"                           "+marks[i]);
			
			
		}
		System.out.println("----------------------------------");
		
		int totalMarks = total(marks);
		System.out.println("Total marks obtained = "+totalMarks);
		
		double percentage;
		
		percentage = totalMarks/7;
		System.out.println("Total Percentage = "+percentage);	
			
		}
	
	static int total(int marks[]) {
		
		int total = 0;
		for(int x: marks) {
			total = total +x;
			
			
		}
		return total;
		
		
		}
		
	}

			
		
		
		


	
	
		
	
	
		
		
		
		
	
	
