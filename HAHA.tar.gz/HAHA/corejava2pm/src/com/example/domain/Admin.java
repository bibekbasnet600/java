package com.example.domain;

import Ineritancexamples.Employee;

public class Admin extends Employee{

	protected Admin(int empld, String name, String ssn, double salary) {
		super(empld, name, ssn, salary);
		// TODO Auto-generated constructor stub
	}
	


}
