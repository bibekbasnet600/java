package com.example.domain;

import Ineritancexamples.Manager;

public class Director extends Manager{
	private double budget;
	
	public Director(int empld, String name, String ssn, double salary, String deptName, double budget ) {
		super(empld, name, ssn, salary, deptName);
		this.budget = budget;
		// TODO Auto-generated constructor stub
	}
	public double getBudget() {
		return budget;
	}

	
	

}
