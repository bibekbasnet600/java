package com.example.domain;

import Ineritancexamples.Employee;

public class Engineer extends Employee {

	Engineer(int empld, String name, String ssn, double salary) {
		
		super(empld, name, ssn, salary);
//		this.getEmpld();
//		this.getName();
//		this.getSsn();
//		this.getSalary();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
