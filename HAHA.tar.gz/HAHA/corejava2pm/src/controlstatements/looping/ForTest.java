package controlstatements.looping;

public class ForTest {

	
	/*
	 * 	Syntax:
	 * 
	 * 		for(initialization; condition; increment/decrement){
	 * 
	 * 			//statements
	 * 	
	 * 		}
	 * 
	 * 
	 */
	
	public static void main(String[] args) {
		
		for(int i = 1; i<=50; i++) {
			
			System.out.println("Hello");
			
		}
		
		
		
	}
	
}
