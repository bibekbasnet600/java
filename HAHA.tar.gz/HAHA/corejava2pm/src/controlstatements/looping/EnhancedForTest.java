package controlstatements.looping;

public class EnhancedForTest {
	
	/*
	 * =========== Enhanced for loop ==================
	 * 	
	 * 
	 * Syntax:
	 * 			
	 * 		for(data_type variable_name : collection){
	 * 	
	 * 		//statements
	 * 
	 * 		}	
	 * 
	 */
	
	public static void main(String[] args) {
		
		int values[] = {9,82,7,34,91,8,25,75,98,17};
		int sum = 0;
		
		
		for(int x : values) {
			sum = sum + x;
			
			System.out.println(x);
			
			
		}
		System.out.println("sum = "+sum);
		
		
	}

}
