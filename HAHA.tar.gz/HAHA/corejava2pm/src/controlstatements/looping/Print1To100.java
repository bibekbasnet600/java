package controlstatements.looping;

public class Print1To100 {
	
	public static void main(String[] args) {
		
		int sum = 0;
		int esum = 0;
		int osum = 0;
		for(int i=1; i<=100; i++) {
			
			if(i%2==0) {
				esum = esum + i;
			}else {
				osum = osum +i;
			}
			
			sum = sum + i;
			
			System.out.println(i);
			
			
		}
		System.out.println("Sum = "+sum);
		System.out.println("esum = "+esum);
		System.out.println("osum = "+osum);
	}

}
