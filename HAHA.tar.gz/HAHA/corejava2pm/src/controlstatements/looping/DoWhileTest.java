package controlstatements.looping;

public class DoWhileTest {
	
	/*
	 * 
	 * 	Syntax:
	 * 
	 * 		do{
	 * 			
	 * 		//statement
	 * 		//increment/decrement
	 * 
	 * 
	 * 		}while(condition){
	 * 
	 * 
	 * 		}
	 * 
	 * 
	 * 
	 */

	
	public static void main(String[] args) {
		
		int a = 8;
		int b = 1;
		
		
		do {
			
			System.out.println(a+" * "+b+" = "+(a*b));
			
			b++;
			
		}while(b<=10);
		
	}
}
