package controlstatements;

public class ControlStmDocs {
	
	/*
	 * ============= Control Statements =====================
	 *
	 * #use to implement logics or conditions in the program
	 *
	 * #Types:
	 * 
	 * 1. selection(Decision Making)
	 * 	a. if
	 * 	b. if-else
	 * 	c. nested if-else
	 * 	d. if-else ladder
	 * 	e. switch
	 * 
	 * 2. Looping(Iteration)
	 * 	a. for
	 * 	b. enhanced for loop
	 * 	c. while
	 * 	d. do-while
	 * 
	 * 3. Jumping(Branching)
	 * 	a. break
	 * 	b. continue
	 *  c. return
	 *
	 *
	 *
	 *
	 *
	 */

}
