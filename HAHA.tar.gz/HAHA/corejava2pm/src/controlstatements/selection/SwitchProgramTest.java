package controlstatements.selection;

import java.util.Scanner;

public class SwitchProgramTest {
	
	public static void main(String[] args) {
		
		String post;
		
		int basicSalary;
		double bonus;
		double actualSalary;
		
		System.out.println("Posts :");
		System.out.println("MD");
		System.out.println("Manager");
		System.out.println("CEO");
		System.out.println("Helper");
		
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter your post : ");
			post = sc.nextLine();
			
			System.out.println("Enter your basic salary :");
			basicSalary = sc.nextInt();
			
			System.out.println("Enter your bonus: ");
			bonus = sc.nextDouble();
		}
		actualSalary = basicSalary * bonus;
		
		switch(post) {
		
		case "MD":
			System.out.println("Your basic salary = "+basicSalary);
			System.out.println("Your bonus = "+bonus);
			System.out.println("Your actual salary = "+actualSalary);
			break;
			
			
		case "Manager":
			System.out.println("Your basic salary = "+basicSalary);
			System.out.println("Your bonus = "+bonus);
			System.out.println("Your actual salary = "+actualSalary);
			break;
			
		case "CEO":
			System.out.println("Your basic salary = "+basicSalary);
			System.out.println("Your bonus = "+bonus);
			System.out.println("Your actual salary = "+actualSalary);
			break;
			
			
		case "Helper":
			System.out.println("Your basic salary = "+basicSalary);
			System.out.println("Your bonus = "+bonus);
			System.out.println("Your actual salary = "+actualSalary);
				break;
				
		default:
			System.out.println("Invild Input");
			
		
		}
		
		
			
			
		
		
		
		
		
		
		
	}

}
