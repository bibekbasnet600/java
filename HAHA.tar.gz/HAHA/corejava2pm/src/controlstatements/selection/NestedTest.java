package controlstatements.selection;

import java.util.Scanner;

public class NestedTest {
	
	/*
	 * ========================= Nested if-else ============
	 * 
	 * Syntax:
	 * 	
	 * 	if(condition-1){
	 * 
	 * 		if(condition-2){
	 * 
	 * 
	 * 
	 * 
	 * 		}else{
	 * 
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 	}else{
	 * 
	 * 
	 * 	}
	 * 
	 * 
	 */
	
	public static void main(String[] args) {
		
		String citizen;
		int age;
		boolean haveVoterId = true;
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter your country citizenship : ");
			citizen = sc.nextLine();
			
			System.out.println("Enter your age :");
			age = sc.nextInt();
		}
		if(citizen.equals("Nepali")) {
			
			if(age >=18) {
				
				if(haveVoterId) {
					
					System.out.println("You can vote.");
					
				}else {
					
					System.out.println("Your don't have voter Id.");
					
					
				}
				
				
				
				
			}else {
				System.out.println("Your age is restricted.");
				
				
			}
			
			
		}else {
			
			System.out.println("Invalid citizenship.");
			
			
			
		}
		
	
	
	}

}
