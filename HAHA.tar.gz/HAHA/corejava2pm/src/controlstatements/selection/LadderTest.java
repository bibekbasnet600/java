package controlstatements.selection;

public class LadderTest {
	
	
	/*
	 * =============== Ladder(else if)==============
	 * 
	 * 	Syntax:
	 * 		
	 * 		if(){
	 * 
	 * 		
	 * 	}
	 * 		else if(){
	 * 
	 * 
	 * 	}
	 * 		else if(){
	 * 
	 * 
	 * 	}
	 * 		else{
	 * 
	 * 	
	 * 	}
	 * 
	 * 
	 */
	
	public static void main(String[] args) {
		
		int marks = 76;
		
		if(marks >=80) {
			
			System.out.println("Distinction.");
			
		}
		
		else if(marks >= 70) {
			
			System.out.println("First Division.");
		}
		
		else if(marks >= 60) {
			
			
			System.out.println("Second Division.");
		}
		
		else if(marks >= 40) {
			
			System.out.println("Third Division.");
			
		}
		else {
			
			System.out.println("Failed.");
		}
	}

}
