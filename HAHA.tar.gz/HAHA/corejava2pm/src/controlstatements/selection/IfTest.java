package controlstatements.selection;

import java.util.Scanner;

public class IfTest {
	
	/*
	 * =============== if ================
	 * 
	 *  #use to handle single condition.
	 *  
	 *  Syntax:
	 *  
	 *  if(condition){
	 *  
	 *  
	 *  	}
	 * 
	 */
	
	public static void main(String[] args) {
		
		int salary;
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter your salary : ");
			
			salary = sc.nextInt();
		}
		
		if(salary < 30000) {
			
			salary = salary + 7000;
		}
		
		System.out.println("Your salary = "+salary);
		
	}

}
