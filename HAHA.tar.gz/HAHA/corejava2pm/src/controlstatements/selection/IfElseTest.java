package controlstatements.selection;

import java.util.Scanner;

public class IfElseTest {
	
	public static void main(String[] args) {
		
		int a;
		int b;
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the value of a :");
			a = sc.nextInt();
			
			System.out.println("Enter the value of b :");
			b = sc.nextInt();
		}
		
		if(a>b) {
			
			System.out.println("The value of a is greater.");
			
			
		}else {
			
			System.out.println("The value of b is greater.");
		}
	
	}

}
