package controlstatements.selection;

import java.util.Scanner;

public class TwoValuesSum {
	
	
public static void main(String[] args) {
		
		int x;
		int y;
		int sum;
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the value of x :");
			x = sc.nextInt();
			System.out.println("Enter the value of y :");
			y = sc.nextInt();
		}
		sum = x + y;
		
		if(x!=0 && y!=0) {
			
			System.out.println("The sum of x and y is :" +sum);
			
		}
		
		
		
	}

}

