package abstraction;

public class AbstractionDocs {
	
	/*
	 *  =========================== Abstraction =================
	 *  
	 *  # process of hiding implementation details in the programs.
	 * 
	 *	# To achieve abstraction : 
	 *		
	 *		a. Abstract class:
	 *		
	 *			# class which contains abstract (Un-implemented) and non abstracts (implemented ) methods. 
	 *
	 *			# abstract methods : 
	 *			
	 *				->methods which doesnot have body / implementation details.
	 *				e.g.
	 *					abstract void print();
	 *					abstract int getValue();
	 *
	 *			# every abstract class have atleast one child class and child class must override abstract methods.
	 *			
	 *			# we can't create objects of abstract class.
	 *
	 *			# syntax : 
	 *				
	 *				abstract class class_name{
	 *
	 *									//abstracts methods
	 *									//non-abstracts methods.
	 *															
	 *											}
	 *		
	 *		b. Interface: 
	 *				
	 *			# same as class which contains public abstract methods and public static final variables.
	 *
	 *			# we can't create object of interface.
	 *
	 *			# every inteface have atleast one implementation class and impl must overrides abstracts methods.
	 *
	 *			# 100% abstraction.
	 *
	 *			# syntax :
	 *				
	 *				interface interface_name{
	 *
	 *								// public abstract methods.
	 *								// public final variables.
	 *								}
	 *
	 *		
	 * 
	 */

}
