package abstraction;

public abstract class CentralBank {
	
	
	abstract void getBankName();
	abstract void getInterestRate();
	void moneyExchangeRate() {
		
		System.out.println("$1 = Rs.132");
		System.out.println("1 Euro = Rs.145");
		System.out.println("100 IC = Rs.160");
	}

}
