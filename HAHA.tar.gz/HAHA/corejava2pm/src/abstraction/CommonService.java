package abstraction;

public interface CommonService {
		
		void print();
}
