package abstraction;

public interface UserService extends CommonService{
	
	void addUser();
	void deleteUser();

}
