package objectwithmethod;

public class ObjectWithMethodDocs {
	
	/*
	 *  ================== object with method ==================
	 *  
	 *  1. Object as parameter:
	 *  	
	 *  	Student class => id,fn,ln,college,age,rollno,.....30th.
	 *  	
	 *  	void print(Student s){
	 *  		
	 *  	}
	 *  
	 *  	Student st = new Student();
	 *  	st.id =93;
	 *  	..........
	 *  	...........
	 *  	...........
	 *  	print(st);
	 * 
	 *  2. Object as return type:
	 *  		
	 *  	Student getValue(){
	 *  
	 *  	Student s = new Student();
	 *  	
	 *  	s.id = 93;
	 *  	...........
	 *  	...........
	 *  	...........
	 *  
	 *  	return s;
	 *  
	 *  	}
	 * 
	 * 
	 * 
	 * 
	 * 
	 */

}
