package objectwithmethod;

public class Test {
	
	public static void main(String[] args) {
		
//		Product p = new Product();
//		
//		p.setId(2);
//		p.setName("Lotion");
//		p.setPrice(1000);
//		p.setCompany("Nevia");
		
		Test t = new Test();
		Product p = t.getProduct();
		t.printProduct(p);
		
		
		
		
		
		
	}
	
	//======= Object as parameter =================
	
	void printProduct(Product p) {
		
		System.out.println("Id = "+p.getId());
		System.out.println("Name = "+p.getName());
		System.out.println("Price = "+p.getPrice());
		System.out.println("Company = "+p.getCompany());
		
		
	}
	// ====================== Object as return type ===================
	Product getProduct() {
		
		Product p = new Product();
		
		p.setId(2);
		p.setName("Lotion");
		p.setPrice(1000);
		p.setCompany("Nevia");
		
		return p;
		
	}

}
