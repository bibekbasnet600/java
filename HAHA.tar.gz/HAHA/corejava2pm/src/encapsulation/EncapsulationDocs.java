package encapsulation;

public class EncapsulationDocs {
	
	/*
	 *  ==================== Encapsulation ====================
	 *  
	 *  #data hiding and binding process:
	 *  
	 *  # To achieve encapsulation:
	 *  	
	 *  	a. declare properties of class as primitive(ie. data hiding).
	 * 		b. create public getters and setters methods to get and set values 
	 * 			to private properties.(i.e. data binding).
	 * 
	 */

}
