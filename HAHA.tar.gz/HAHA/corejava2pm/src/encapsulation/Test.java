package encapsulation;

public class Test {
	
	public static void main(String[] args) {
		
		Customer c = new Customer();
		
		
		
//		c.id = 101;
//		c.name = "Raghav Basnet";
//		c.age = 28;
//		c.city = "Hamburg";
//		c.phone = "+51 323 85 295";
		
		c.setId(101);
		c.setName("Raghav Basnet");
		c.setAge(28);
		c.setCity("Hamburg");
		c.setPhone("+51 246 526 262 62");
		
		
//		System.out.println("Id = "+c.getId());
//		System.out.println("name = "+c.getName());
//		System.out.println("age = "+c.getAge());
//		System.out.println("city = "+c.getCity());
//		System.out.println("phone = "+c.getPhone());
		
		System.out.println(c);
}
}
