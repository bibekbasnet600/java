package Ineritancexamples;

public class Employee {
	
	private int empld;
	private String name;
	private String ssn;
	private double salary;
	
	
	public Employee(int empld, String name, String ssn, double salary){
		
		this.empld = empld;
		this.name = name;
		this.ssn = ssn;
		this.salary = salary;
	}
	
	public int getEmpld() {
		return empld;
	}
//	public void setEmpld(int empld) {
//		this.empld = empld;
//	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSsn() {
		return ssn;
}
//	public void setSsn(String ssn) {
//		this.ssn = ssn;
//	}
	public double getSalary() {
		return salary;
	}
//	public void setSalary(double salary) {
//		this.salary = salary;
//	}
	
	
	
	public void printEmployee() {
		
		System.out.println("EMployee id = "+empld);
		System.out.println("Name  = "+name);
		System.out.println("Social security number = "+ssn);
		System.out.println("Salary = "+salary);
	}
	
	

}
