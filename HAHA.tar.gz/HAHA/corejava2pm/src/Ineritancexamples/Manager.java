package Ineritancexamples;

public class Manager extends Employee {
	private String deptName;
	public Manager(int empld, String name, String ssn, double salary, String deptName) {
		super(empld, name, ssn, salary);
		this.deptName = deptName;
		// TODO Auto-generated constructor stub
	}


	
	
	
	public String getDeptName() {
		return deptName;
		
		
	}
	
	
	

}
