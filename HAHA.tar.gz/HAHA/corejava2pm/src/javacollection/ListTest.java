package javacollection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListTest {
	
	public static void main(String[] args) {
		
		List<String> list = new ArrayList<>();
		LinkedList<String> list1 = new LinkedList<>();
		
		// Using Linked List
		list1.add("France");
		list1.add("Bulgaria");
		list1.add("Austria");
		list1.add("Turkey");
		// USing Array List
		list.add("Nepal");
		list.add("Germany");
		list.add("Japan");
		list.add("Canada");
		list.add("Italy");
		
		
		
		for(String s : list) {
			System.out.println(s);
			
		}
		for(String s : list1) {
			System.out.println(s);
			
		}
		
	}

}
