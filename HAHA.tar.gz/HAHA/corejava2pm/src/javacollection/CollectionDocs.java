package javacollection;

public class CollectionDocs {

	
		/*
		 * ==================== Collection Framework (java collection) ================
		 * 
		 * # use to store and processing dynamic multiple data/values/objects.
		 * 
		 * 1. List : dynamic array
		 * 		a. ArrayList	: Slow Processing, better to use for data storage.
		 * 		b. LinkedList	: Fast processing, better to use for data processing.
		 * 
		 * 2. Set  : collection of unique data
		 * 		a. HashSet		: unique data only.
		 * 		b. TreeSet		: unique + sorted data.
		 * 		c. LinkedHashSet: unique + insertion in order.
		 * 		
		 * 3. Map  : data manage in key and value pair
		 * 		a. HashMap		: <K,V> pair.
		 * 		b. TreeMap		: <K,V> + sorted data.
		 * 		c. LinkedHashMap: <K,V> + insertion in order.
		 * 
		 * 
		 * 
		 */
}
