package javacollection;


import java.util.LinkedHashSet;
import java.util.Set;


public class SetTest {
	
	public static void main(String[] args) {
		
		//Set<String> hset = new HashSet<>();
		//Set<String> hset = new TreeSet<>();
		Set<String> hset = new LinkedHashSet<>();
		
		
		hset.add("Java");
		hset.add("Andriod");
		hset.add("PHP");
		hset.add("Java");
		hset.add("Python");
		hset.add("Ruby");
		hset.add("Andriod");
		hset.add("XML");
		
		for(String s : hset) {
			System.out.println(s);
			
			
		}
		
		
	}

}
