package methods;

public class ReturnTypeWithNoParameter {
	


	public static void main(String[] args) {
		
		int x = sumOf1To100();
		System.out.println("Sum of 1 to 100 = "+x);
		
		}
	
	static int sumOf1To100() {
		
		int num = 100;
		int sum =0;
		
		for(int i = 1; i<=num; i++) {
			
		sum = sum +i;

		
	}
		return sum;
	}
	
	
}
	

