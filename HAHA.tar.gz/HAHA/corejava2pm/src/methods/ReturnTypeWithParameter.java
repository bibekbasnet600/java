package methods;

public class ReturnTypeWithParameter {
	
	public static void main(String[] args) {
		
		int sv = findSmallestValue(200,600);
		System.out.println("Smallest value = "+sv);
		
		
	}
	
	static int findSmallestValue(int x, int y) {
		
		if(x<y) {
			
			return x;
			
		}
			return y;
		
		
	}

}
