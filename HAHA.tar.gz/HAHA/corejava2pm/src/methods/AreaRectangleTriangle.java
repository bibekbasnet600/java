package methods;

import java.util.Scanner;

public class AreaRectangleTriangle {
	
	
	public static void main(String[] args) {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a value of length : ");
			int l = sc.nextInt();
			
			System.out.println("Enter a value of breadth : ");
			int b = sc.nextInt();
			
			findArea(l, b);
		}
		
		
		
	}
	
	static void findArea(int l, int b) {
		
		int area = l*b;
		System.out.println("The area of traingle = "+area);
		
	
		
	}

}
