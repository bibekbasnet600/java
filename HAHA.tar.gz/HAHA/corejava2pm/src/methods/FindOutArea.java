package methods;

public class FindOutArea {
	
	public static void main(String[] args) {
		
		area();
		
	}
	
	static void area() {
		
		int l = 5;
		int b = 6;
		
		int a = l*b;
		
		System.out.println("Area = "+a);
		
		
	}

}
