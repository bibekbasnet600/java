package methods;

import java.util.Scanner;

public class ConvertNprToDollar {
	
	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the value of nepali rs"); 
			float n = sc.nextInt();
			convertn(n);
		}
		
		
	}
	
	static void convertn(float n) {
		
		float d = n/132;
		System.out.println("Nepali Rs. to dollar ="+d);
			
		}		
		
	}


