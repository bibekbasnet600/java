package methods;

public class MethodTest {
	

		public static void main(String[] args) {
			
		//add();
		printTable(7);
			
		}
		
		static void add() {
			
			int a = 4;
			int b = 5;
			
			int sum = a+b;
			System.out.println("Total = "+sum);
			
			
		}
		
		// 2. no return type with parameter.
		
		static void printTable(int n) {
			
			for(int i = 1; 1<=10; i++) {
				
				System.out.println(n +"*"+ i +"="+(n*i));
				
			}			
		}
		
}
