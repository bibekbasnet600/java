package methods.test;

import java.util.Scanner;

public class AreaOfTriangle {
	
public static void main(String[] args) {
		
	
		areaTriangle();
		
	}
	
	static void areaTriangle() {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a value of heigth : ");
				
			float h = sc.nextFloat();
				
				
			System.out.println("Enter a value of breadth : ");
				
			float b = sc.nextFloat();
				
				
			float area = ((1/2f)*b*h);
				
			System.out.println("The area of traingle = "+area);
		}
		
	}
		
		
		
	}


