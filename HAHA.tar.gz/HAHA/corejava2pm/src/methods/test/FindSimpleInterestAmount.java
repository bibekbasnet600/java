package methods.test;

import java.util.Scanner;

public class FindSimpleInterestAmount {
	
	public static void main(String[] args) {
		
		
		input();
		
	}
	
	static void input() {
		
		try (Scanner ss = new Scanner(System.in)) {
			System.out.println("Enter the value of p :");
			
			int p = ss.nextInt();
			System.out.println("Enter the time duaration: ");
			float t = ss.nextFloat();

			
			System.out.println("Enter the interest rate: ");
			float r = ss.nextFloat();

			processing(p, t, r);
		}
		
	}
	
	static void processing(int p, float t, float r) {

		float si = (p*t*r)/100;
		float amount = si+p;
		output(si, amount);
		
		
	}
	static void output(float si, float amount) {
		System.out.println("Simple interest : "+si);
		System.out.println("Amount : "+amount);
		
	}

}
