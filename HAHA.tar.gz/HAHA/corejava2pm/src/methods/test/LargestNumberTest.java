package methods.test;

import java.util.Scanner;

public class LargestNumberTest {
	
	
	public static void main(String[] args) {
		
		input();
		
	}
	
	static void input() {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a first number : ");
			int a = sc.nextInt();
			
			System.out.println("Enter a second number : ");
			int b = sc.nextInt();
			
			System.out.println("ENter a third number : ");
			int c = sc.nextInt();
			
			processing(a, b, c);
		}
		
	}
	
	static void processing(int a, int b, int c) {
		
		if(a>b && a>c) {
			
			System.out.println("First number is greater.");
			
		}
		else if(b>a && b>c){
			
			System.out.println("Second number is greater. ");
			
		}
		else if(c>a && c>b) {
			
			System.out.println("Third number is greater. ");
		}
		
		
		
	}
	
	

}
