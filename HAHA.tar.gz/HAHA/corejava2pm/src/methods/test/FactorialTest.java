package methods.test;

import java.util.Scanner;

public class FactorialTest {
	
	public static void main(String[] args) {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter any number for factorial : ");
			int x = sc.nextInt();
			
			fact(x);
		}
		
	}
	
	static void fact(int x) {
		
		
		for(int i=1; i<=10; i++) {
			
			int f = x*i;
			
			System.out.println(x+ " * " +i +" = " +f);
		
			
		}
		
		
	}
	
}
