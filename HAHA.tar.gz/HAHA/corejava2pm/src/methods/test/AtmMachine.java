package methods.test;

import java.util.Scanner;

public class AtmMachine {
	
	
	public static void main(String[] args) {
	
		int x = test();
		System.out.println("Your remaining balance = "+x);
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter your deposit amount :");
			int deposit = sc.nextInt();
			
			int y = test2(x, deposit);
			
			System.out.println("Your actual balance after deposit is : "+y);
		}
		
		
			
	}
	
	static int test() {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter your balance : ");
			int balance = sc.nextInt();
			
			System.out.println("Enter a withdrawl amount : ");
			int wd = sc.nextInt();
			
			int rb = balance - wd;
			
			
			return rb;
		}
		
		
	}
	static int test2(int x, int deposit) {
		
		int actualBalance = x+deposit;
		
		return actualBalance;
		
		
		
		
	}

}