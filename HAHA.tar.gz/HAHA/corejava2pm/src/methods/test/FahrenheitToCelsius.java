package methods.test;

import java.util.Scanner;

public class FahrenheitToCelsius {
	
	public static void main(String[] args) {
		
		convertToCelcius();
		
		
		
		
	}
	
	static void convertToCelcius() {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the value of fahrenheit : ");
			float f = sc.nextFloat();
			
			float c = 33.8f;
			
			float t = f*c;
			
			System.out.println(f+" Fahrenheit = "+t+" celsius ");
		}
		
		
	
	}
	
	
	

}
