package methods.test;

import java.util.Scanner;

public class PoundToKg {
	
	
	public static void main(String[] args) {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the value of pound : ");
			float p = sc.nextFloat();
			
			convertPound(p);
		}
		
		
	}
	
	static void convertPound(float p) {
		
		float k = 0.454f;
		float t = p*k;
		
		System.out.println(p+ " pound "+ "= "+t+ "kg");
		
		
	}

}
