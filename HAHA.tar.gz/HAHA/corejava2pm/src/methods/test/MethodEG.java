package methods.test;

import java.util.Scanner;

public class MethodEG {
	
	public static void main(String[] args) {
		
		int x = getArea();
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a value of h: ");
			int h = sc.nextInt();
			System.out.println("Area of rectangle : "+x);
			
			int vol = volume(x, h);
			System.out.println("The voulme of rectangle : "+vol);
		}
		
	}
	static int getArea() {
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a value of l : ");
			int l = sc.nextInt();
			
			System.out.println("Enter a value of b: ");
			int b = sc.nextInt();
			
			int area = l*b;
			
			return area;
		}
		
		
	}
	static int volume(int x, int h) {
		
		int v = x*h;
		
		
		return v;
		
	}
}
