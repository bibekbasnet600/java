package constructor;

public class ConstructorDocs {
	
	/*
	 * ===================== Constructor ========================
	 *
	 * # use to create object in java.
	 * 
	 * # special type of method which has same name as class name.
	 * 
	 * # constructor does not have return type.
	 * 
	 * # if there is no user defined constructor in your class then java provides default constructor.
	 * 
	 * # Types :
	 * 
	 * a. default constructor:s
	 *		
	 *		# use to create object with default values.
	 *		
	 *		# syntax : 
	 *			
	 *			class_name(){
	 *
	 *				//set default values to object.
	 *				}
	 * 
	 * b. Parameterized constructor:
	 * 		
	 * 		# use to create object with dynamic values.
	 * 		
	 * 		# syntax :
	 * 			
	 * 			class_name(arg1, arg2, arg3,......., argn){
	 * 
	 * 				//set dynamic values to object.
	 * 
	 * 			}
	 * 
	 */

}
