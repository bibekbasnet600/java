package constructor;

public class User {
	
	String userName;
	String password;
	
	//=============== default constructor ==============
	
	//	User(){
	//		
	//		userName = "root";
	//		password = "1234";
	//	}
	
	//============== parameterized constructor =====================
	
	User(String un, String psw){
		
		userName = un;
		password = psw;
		//we can call methods using this keywords.
		
	}
	
	
	
	void printUser() {
		
		System.out.println("UserName = "+userName);
		System.out.println("Password = "+password);
		
		
	}
	
	public static void main(String[] args) {
		
		User u = new User("root","7911");
		u.printUser();
		
	}

}
