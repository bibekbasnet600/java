package java_swing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ButtonGroup;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.AbstractMap.SimpleImmutableEntry;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class TableForm extends JFrame {

	private JPanel contentPane;
	private JTextField nameTxt;
	private JTextField addressTxt;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TableForm frame = new TableForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TableForm() {
		setTitle("TABLE FORM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 841, 620);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(32, 178, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(42, 14, 70, 15);
		contentPane.add(lblNewLabel);
		
		nameTxt = new JTextField();
		nameTxt.setBounds(105, 12, 178, 19);
		contentPane.add(nameTxt);
		nameTxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Address");
		lblNewLabel_1.setBounds(301, 14, 70, 15);
		contentPane.add(lblNewLabel_1);
		
		addressTxt = new JTextField();
		addressTxt.setBounds(389, 12, 154, 19);
		contentPane.add(addressTxt);
		addressTxt.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("College");
		lblNewLabel_2.setBounds(569, 14, 70, 15);
		contentPane.add(lblNewLabel_2);
		
		JComboBox collegeCmb = new JComboBox();
		collegeCmb.setModel(new DefaultComboBoxModel(new String[] {"SELECT", "NCC", "KEC", "ISMT", "SNSC", "PMC"}));
		collegeCmb.setBounds(642, 9, 114, 24);
		contentPane.add(collegeCmb);
		
		JLabel lblNewLabel_3 = new JLabel("Gender");
		lblNewLabel_3.setBounds(42, 79, 70, 15);
		contentPane.add(lblNewLabel_3);
		
		JRadioButton maleBtn = new JRadioButton("Male");
		buttonGroup.add(maleBtn);
		maleBtn.setBounds(113, 75, 85, 23);
		contentPane.add(maleBtn);
		
		JRadioButton femaleBtn = new JRadioButton("Female");
		buttonGroup.add(femaleBtn);
		femaleBtn.setBounds(227, 75, 101, 23);
		contentPane.add(femaleBtn);
		
		JCheckBox AgreeBtn = new JCheckBox("Agree");
		AgreeBtn.setBounds(368, 75, 129, 23);
		contentPane.add(AgreeBtn);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nm = nameTxt.getText();
				String adr = addressTxt.getText();
				String colz = collegeCmb.getSelectedItem().toString();
				
				String gender;
				
				if(maleBtn.isSelected()) {
					
					gender="Male";
					
				}else {
					
					gender ="Female";
				}
				
				String agree;
				
				if(AgreeBtn.isSelected()) {
					
					agree = "Yes";
					
				}else{
					
					agree = "No";
					
				}
				
				if(nameTxt.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(nameTxt, "Name Required");
					return;
					
				}
				if(addressTxt.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(addressTxt, "Address Required");
					return;
				}
				if(collegeCmb.getSelectedItem().toString().equals("SELECT")) {
					
					JOptionPane.showMessageDialog(collegeCmb, "Select your college");
					return;
					
				}
				
				if(buttonGroup.isSelected(null)) {
					
					JOptionPane.showMessageDialog(null, "Select you Gender");
					return;
				}
				
				
				
				
				
				
				
				//Create Table Form
				
				DefaultTableModel tmodel =(DefaultTableModel) table.getModel();
				tmodel.addRow(new Object[] {nm,adr,colz,gender,agree});
		
				
//				nameTxt.setText("");
//				addressTxt.setText("");
//				collegeCmb.setSelectedIndex(0);
//				buttonGroup.clearSelection();
//				AgreeBtn.setSelected(false);
				
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con	= DriverManager.getConnection("jdbc:mysql://localhost:3306/tableform", "root", "Bibek72981!@");
				
				String sql = "insert into tableDetails(name,address,college,gender,agree)values('"+nm+"','"+adr+"','"+colz+"','"+gender+"','"+agree+"')";
				Statement stm = con.createStatement();
				
				stm.execute(sql);
				
				JOptionPane.showMessageDialog(null, "ADDED SUCCESS");
				
				nameTxt.setText("");
				addressTxt.setText("");
				collegeCmb.setSelectedIndex(0);
				buttonGroup.clearSelection();
				AgreeBtn.setSelected(false);
					
					
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
				
				
				
				
				
				
			}
		});
		btnNewButton.setBounds(542, 74, 117, 25);
		contentPane.add(btnNewButton);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 110, 1009, 15);
		contentPane.add(separator);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(56, 485, 700, -347);
		contentPane.add(scrollPane);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(46, 150, 749, 381);
		contentPane.add(scrollPane_1);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Name", "Address", "College", "Gender", "Agree"
			}
		));
		scrollPane_1.setViewportView(table);
		
		JButton btnNewButton_1 = new JButton("Clear Table");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			DefaultTableModel tmodel =	(DefaultTableModel) table.getModel();
			tmodel.setRowCount(0);
			}
		});
		btnNewButton_1.setBounds(694, 74, 117, 25);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Print Table");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					table.print();
				} catch (PrinterException e1) {
					
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(678, 543, 117, 25);
		contentPane.add(btnNewButton_2);
	}
}
