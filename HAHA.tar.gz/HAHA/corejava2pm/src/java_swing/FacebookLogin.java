package java_swing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JDateChooser;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FacebookLogin extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JTextField fname;
	private JTextField lname;
	private JTextField emailTxt;
	private JTextField textField_4;
	private JPasswordField passwordTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FacebookLogin frame = new FacebookLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FacebookLogin() {
		setTitle("Facebook Login Page");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1054, 629);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(220, 220, 220));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(30, 144, 255));
		panel.setBounds(0, -13, 1054, 103);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Facebook");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel.setBounds(35, 31, 206, 36);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setBounds(558, 8, 126, 36);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(714, 10, 188, 33);
		panel.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBorder(null);
		textField.setBounds(558, 42, 126, 19);
		panel.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBorder(null);
		passwordField.setBounds(713, 42, 136, 19);
		panel.add(passwordField);
		
		JButton btnNewButton = new JButton("Log In");
		btnNewButton.setBorder(null);
		btnNewButton.setBackground(new Color(30, 144, 255));
		btnNewButton.setBounds(861, 36, 117, 25);
		panel.add(btnNewButton);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Keep Me Logged In");
		chckbxNewCheckBox.setBackground(new Color(30, 144, 255));
		chckbxNewCheckBox.setFont(new Font("Dialog", Font.PLAIN, 10));
		chckbxNewCheckBox.setBounds(558, 69, 126, 23);
		panel.add(chckbxNewCheckBox);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 191, 255));
		panel_1.setBounds(497, 98, 523, 470);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("First Name : ");
		lblNewLabel_3.setBounds(25, 12, 135, 15);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Last Name : ");
		lblNewLabel_4.setBounds(25, 53, 106, 15);
		panel_1.add(lblNewLabel_4);
		
		fname = new JTextField();
		fname.setBounds(149, 10, 206, 19);
		panel_1.add(fname);
		fname.setColumns(10);
		
		lname = new JTextField();
		lname.setBounds(149, 53, 206, 19);
		panel_1.add(lname);
		lname.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Your Email : ");
		lblNewLabel_5.setBounds(25, 104, 106, 15);
		panel_1.add(lblNewLabel_5);
		
		emailTxt = new JTextField();
		emailTxt.setBounds(148, 102, 207, 19);
		panel_1.add(emailTxt);
		emailTxt.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Re-Enter Email : ");
		lblNewLabel_6.setBounds(25, 152, 135, 32);
		panel_1.add(lblNewLabel_6);
		
		textField_4 = new JTextField();
		textField_4.setBounds(149, 152, 206, 19);
		panel_1.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("New Password :");
		lblNewLabel_7.setBounds(25, 214, 135, 15);
		panel_1.add(lblNewLabel_7);
		
		passwordTxt = new JPasswordField();
		passwordTxt.setBounds(149, 212, 206, 19);
		panel_1.add(passwordTxt);
		
		JLabel lblNewLabel_8 = new JLabel("I AM : ");
		lblNewLabel_8.setBounds(25, 258, 122, 24);
		panel_1.add(lblNewLabel_8);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"------- Select Gender -------", "Male", "Female", "Other"}));
		comboBox.setBounds(149, 253, 206, 24);
		panel_1.add(comboBox);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(149, 319, 206, 19);
		panel_1.add(dateChooser);
		
		JLabel lblNewLabel_9 = new JLabel("Birthday : ");
		lblNewLabel_9.setBounds(25, 314, 122, 24);
		panel_1.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Why do i need to provide this?");
		lblNewLabel_10.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblNewLabel_10.setBounds(149, 368, 206, 15);
		panel_1.add(lblNewLabel_10);
		
		JButton btnNewButton_1 = new JButton("Sign Up");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				new LoginForm().setVisible(true);
				dispose();
				
				
				
				
				
			}
		});
		btnNewButton_1.setBounds(196, 388, 117, 25);
		panel_1.add(btnNewButton_1);
		
		JLabel label = new JLabel("");
		label.setBounds(299, 184, 70, 15);
		contentPane.add(label);
	}
}
