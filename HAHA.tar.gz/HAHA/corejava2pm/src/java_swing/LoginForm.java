package java_swing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginForm extends JFrame {

	private JPanel contentPane;
	private JTextField usernameTxt;
	private JPasswordField passwordTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginForm frame = new LoginForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginForm() {
		setForeground(Color.PINK);
		setTitle("Login Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 907, 554);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(30, 144, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("UserName");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel.setBounds(192, 151, 157, 15);
		contentPane.add(lblNewLabel);
		
		usernameTxt = new JTextField();
		usernameTxt.setBounds(332, 144, 216, 33);
		contentPane.add(usernameTxt);
		usernameTxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 20));
		lblNewLabel_1.setBounds(192, 211, 146, 59);
		contentPane.add(lblNewLabel_1);
		
		passwordTxt = new JPasswordField();
		passwordTxt.setBounds(332, 226, 216, 33);
		contentPane.add(passwordTxt);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//JOptionPane.showMessageDialog(null, "Hello");
				String un = usernameTxt.getText();
				String psw = passwordTxt.getText();
				
				//login form validation
				
				if(usernameTxt.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(usernameTxt, "UserName is required.");
					return;
				}
				
				if(passwordTxt.getText().isBlank()){
					JOptionPane.showMessageDialog(passwordTxt, "Password is required.");
					return;
				}
				
				
//				if(un.equals("ram") && psw.equals("123")) {
//					
//					JOptionPane.showMessageDialog(null, "Login Success");
//				new HomePage().setVisible(true);
//					dispose();
//				}else {
//					
//					JOptionPane.showMessageDialog(null, "Login Failed");
//				}
//				
				//check user in DB
				
			
				
			}
		});
		btnNewButton.setBackground(Color.MAGENTA);
		btnNewButton.setBounds(373, 282, 141, 40);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("User Login Form");
		lblNewLabel_2.setForeground(Color.GREEN);
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 30));
		lblNewLabel_2.setBounds(239, 26, 308, 75);
		contentPane.add(lblNewLabel_2);
	}
}
