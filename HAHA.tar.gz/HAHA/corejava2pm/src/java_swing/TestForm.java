package java_swing;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class TestForm {
	
	public static void main(String[] args) {
		
		JFrame form = new JFrame();
		form.setSize(800,600);
		form.setTitle("Test Form");
		form.setLayout(null);
		
		
		//create JLabel
		
		JLabel jl = new JLabel("Welcome To Swing");
		
		jl.setBounds(200, 90, 200, 50);
		form.add(jl);
		
		JLabel jl1 = new JLabel("UserName");
		jl1.setBounds(200, 120, 200, 50);
		form.add(jl1);
		
		JLabel jl2 = new JLabel("Password");
		jl2.setBounds(200, 160, 200, 50);
		form.add(jl2);
		
		JTextField tf = new JTextField();
		tf.setBounds(300, 140, 200, 20);
		form.add(tf);
		
		JPasswordField pf = new JPasswordField();
		pf.setBounds(300, 175, 200, 20);
		form.add(pf);
		
		JButton btn = new JButton("Login");
		btn.setBounds(350, 200, 100, 30);
		form.add(btn);
		
		
		
		form.setVisible(true);
		
	}

}
