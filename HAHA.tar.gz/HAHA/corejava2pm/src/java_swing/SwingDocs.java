package java_swing;

public class SwingDocs {
	
	/*
	 * ================= swing framework ==============
	 * 	
	 * 	#use to create UI/GUI/front end of desktop application in java.
	 * 
	 * 	# UI components:
	 * 		-> JLabel
	 * 		-> JTextField
	 * 		-> JTable
	 * 		-> JRadioButton
	 * 		-> JCheckBox
	 * 		-> JPanel
	 * 		-> JButton
	 * 		-> JComboBox
	 * 
	 * 	# Steps to create any UI component :
	 * 	
	 * 		1. create it (create object).
	 * 			e.g.
	 * 				JButton jb = new JButton();
	 * 
	 * 		2. configure it (set length, breadth, height, location, color, etc).
	 * 
	 * 		3. Add it (add component to container).
	 * 
	 * 		4. Action.
	 * 
	 * 
	 */

}
