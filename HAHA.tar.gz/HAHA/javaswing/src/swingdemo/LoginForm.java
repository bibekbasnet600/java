package swingdemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class LoginForm extends JFrame {

	private JPanel contentPane;
	private JTextField usernameTxt;
	private JPasswordField passwordTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginForm frame = new LoginForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginForm() {
		setTitle("Login Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 761, 501);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("UserName : ");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel.setBounds(130, 71, 137, 41);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password : ");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel_1.setBounds(130, 132, 114, 55);
		contentPane.add(lblNewLabel_1);
		
		usernameTxt = new JTextField();
		usernameTxt.setBounds(265, 77, 169, 30);
		contentPane.add(usernameTxt);
		usernameTxt.setColumns(10);
		
		passwordTxt = new JPasswordField();
		passwordTxt.setBounds(263, 145, 171, 30);
		contentPane.add(passwordTxt);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				new IndexPage().setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setBounds(130, 209, 117, 48);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Login");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String un = usernameTxt.getText();
				String psw = passwordTxt.getText();
				
				if(usernameTxt.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(usernameTxt, "UserName Required");
					return;
					
					
				}
				if(passwordTxt.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(passwordTxt, "Password Required");
					return;
					
					
				}
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/swingdemo", "root", "Bibek72981!@");
					
					String sql = "select * from swing where username = '"+un+"' and password = '"+psw+"'";
					
					Statement stm = con.createStatement();
					ResultSet rs = stm.executeQuery(sql);
					
					if(rs.next()) {
						
						JOptionPane.showMessageDialog(null, "Login Success");
						new HomePage().setVisible(true);
						dispose();
						
					}
					
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
				
				
				
				
//				if(un.equals("ramthapa")&&psw.equals("123")) {
//					
//					JOptionPane.showMessageDialog(null, "Login Success");
//					new HomePage().setVisible(true);
//					dispose();
//					
//				}else {
//					
//					JOptionPane.showMessageDialog(null, "Invalid Credencials");
//				}
				
				
				
			
			}
		});
		btnNewButton_1.setBounds(305, 209, 117, 48);
		contentPane.add(btnNewButton_1);
	}
}
