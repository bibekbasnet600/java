package swingdemo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class SignUpForm extends JFrame {

	private JPanel contentPane;
	private JTextField usernameTxt;
	private JPasswordField passwordTxt;
	private JTextField fname;
	private JTextField lname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUpForm frame = new SignUpForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignUpForm() {
		setTitle("SignUp Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 731, 486);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("UserName : ");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel.setBounds(139, 59, 117, 39);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password : ");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel_1.setBounds(139, 110, 105, 44);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("FirstName : ");
		lblNewLabel_2.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel_2.setBounds(139, 166, 117, 39);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("LastName : ");
		lblNewLabel_3.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel_3.setBounds(139, 217, 117, 39);
		contentPane.add(lblNewLabel_3);
		
		usernameTxt = new JTextField();
		usernameTxt.setBounds(255, 65, 147, 27);
		contentPane.add(usernameTxt);
		usernameTxt.setColumns(10);
		
		passwordTxt = new JPasswordField();
		passwordTxt.setBounds(255, 119, 147, 27);
		contentPane.add(passwordTxt);
		
		fname = new JTextField();
		fname.setBounds(255, 172, 147, 27);
		contentPane.add(fname);
		fname.setColumns(10);
		
		lname = new JTextField();
		lname.setBounds(255, 223, 147, 27);
		contentPane.add(lname);
		lname.setColumns(10);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				new IndexPage().setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(139, 287, 117, 25);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("SignUp");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String un = usernameTxt.getText();
				String psw = passwordTxt.getText();
				String fn = fname.getText();
				String ln = lname.getText();
				
				if(usernameTxt.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(usernameTxt, "UserName Required");
					return;
					
				}
			
				

				if(passwordTxt.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(passwordTxt, "Password Required");
					return;
					
				}

				if(fname.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(fname, "First Name Required");
					return;
					
				}

				if(usernameTxt.getText().isBlank()) {
					
					JOptionPane.showMessageDialog(lname, "Last Name Required");
					return;
					
				}
				
//				if(un.equals("ramthapa") && psw.equals("123") && fn.equals("ram") && ln.equals("thapa")) {
//					
//					JOptionPane.showMessageDialog(null, "SignUp Success");
//					new LoginForm().setVisible(true);
//					
//				}
//				
//				
//				dispose();
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con	= DriverManager.getConnection("jdbc:mysql://localhost/swingdemo", "root", "Bibek72981!@");
				
				String sql = "insert into swing(username,password,FirstName,LastName)values('"+un+"','"+psw+"','"+fn+"','"+ln+"')";
				Statement stm = con.createStatement();
				stm.execute(sql);
				
				JOptionPane.showMessageDialog(null, "SignUp Success");
				
				usernameTxt.setText("");
				passwordTxt.setText("");
				fname.setText("");
				lname.setText("");
				//new LoginForm().setVisible(true);
			
				
					
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_1.setBounds(285, 287, 117, 25);
		contentPane.add(btnNewButton_1);
	}

}
